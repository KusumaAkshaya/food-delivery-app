export interface data
{
    image: string,
}

export const about: data[] = [
    {
        image: '/images/about/fig1.jpg',
    },
    {
        image: '/images/about/fig2.jpg',
    },
    {
        image: '/images/about/fig3.jpg',
    },
    {
        image: '/images/about/fig4.jpg',
    },
]